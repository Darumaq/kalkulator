function dodaj(){

 let liczba1=parseInt(document.getElementById("liczba1").value);

  let liczba2=parseInt(document.getElementById("liczba2").value);

  let wynik1=liczba1+liczba2;

 document.getElementById("wynik").innerHTML=wynik1;
 }
function odejmij(){
let liczba1=parseInt(document.getElementById("liczba1").value);

 let liczba2=parseInt(document.getElementById("liczba2").value);

let wynik2=liczba1-liczba2;

document.getElementById("wynik").innerHTML=wynik2;
}
function mnoz(){
let liczba1=parseInt(document.getElementById("liczba1").value);

let liczba2=parseInt(document.getElementById("liczba2").value);

 let wynik3=liczba1*liczba2;

document.getElementById("wynik").innerHTML=wynik3;
 }
function dziel(){
let liczba1=parseInt(document.getElementById("liczba1").value);

let liczba2=parseInt(document.getElementById("liczba2").value);

let wynik4=liczba1/liczba2;

document.getElementById("wynik").innerHTML=wynik4;
}
function poteguj(){
let liczba1=parseInt(document.getElementById("liczba1").value);

let liczba2=parseInt(document.getElementById("liczba2").value);

let wynik5=Math.pow(liczba1,liczba2);

document.getElementById("wynik").innerHTML=wynik5;

}